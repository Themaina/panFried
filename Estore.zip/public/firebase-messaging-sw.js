importScripts("https://www.gstatic.com/firebasejs/7.6.2/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/7.6.2/firebase-messaging.js");

firebase.initializeApp({
  apiKey: "AIzaSyC07FmUedL6rCav4Yjsb5T81JHQjCDAYr8",
  authDomain: "test1-6c3fe.firebaseapp.com",
  projectId: "test1-6c3fe",
  storageBucket: "test1-6c3fe.appspot.com",
  messagingSenderId: "1009106664713",
  appId: "1:1009106664713:web:23e60dccc3a522de2f27d8",
  measurementId: "G-GEKQDMVVCS",
});

const initMeseging = firebase.messaging();
