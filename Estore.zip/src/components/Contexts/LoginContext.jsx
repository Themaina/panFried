import { createContext } from "react";
const DefaultUser = createContext();
export default DefaultUser;
